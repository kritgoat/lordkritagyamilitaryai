import React, { useState, useMemo } from 'react';
import Header from './components/Header';
import Navigation from './components/Navigation';
import SearchBar from './components/SearchBar';
import CategoryFilter from './components/CategoryFilter';
import LanguageToggle from './components/LanguageToggle';
import TermsList from './components/TermsList';
import AccessibilityPanel from './components/AccessibilityPanel';
import ResponseModal from './components/ResponseModal';
import MartyrsGallery from './components/MartyrsGallery';
import Chatbot from './components/Chatbot';
import { useTerms } from './hooks/useTerms';
import { AppSettings } from './types';
import { terms } from './data/terms';

function App() {
  const {
    terms: filteredTerms,
    searchQuery,
    setSearchQuery,
    selectedCategory,
    setSelectedCategory,
    languageMode,
    setLanguageMode,
    processQuestion
  } = useTerms();

  const [settings, setSettings] = useState<AppSettings>({
    languageMode: 'bilingual',
    fontSize: 16,
    darkMode: false
  });

  const [modalResponse, setModalResponse] = useState<string>('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<string>('dictionary');

  // Calculate term counts by category
  const termCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    terms.forEach(term => {
      counts[term.category] = (counts[term.category] || 0) + 1;
    });
    return counts;
  }, []);

  const handleAskQuestion = (question: string) => {
    const response = processQuestion(question);
    setModalResponse(response);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setModalResponse('');
  };

  return (
    <div 
      className={`min-h-screen transition-colors duration-300 ${
        settings.darkMode ? 'bg-gray-900' : 'bg-gray-50'
      }`}
      style={{ fontSize: `${settings.fontSize}px` }}
    >
      <Header />
      <Navigation activeTab={activeTab} onTabChange={setActiveTab} />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'dictionary' && (
          <div className="space-y-8">
            {/* Search Section */}
            <SearchBar
              value={searchQuery}
              onChange={setSearchQuery}
              onAskQuestion={handleAskQuestion}
            />
            
            {/* Filters Section */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <CategoryFilter
                selectedCategory={selectedCategory}
                onCategoryChange={setSelectedCategory}
                termCounts={termCounts}
              />
              <LanguageToggle
                languageMode={languageMode}
                onModeChange={setLanguageMode}
              />
              <AccessibilityPanel
                settings={settings}
                onSettingsChange={setSettings}
              />
            </div>
            
            {/* Results Section */}
            <TermsList terms={filteredTerms} languageMode={languageMode} />
          </div>
        )}

        {activeTab === 'martyrs' && <MartyrsGallery />}
      </main>

      {/* AI Response Modal */}
      <ResponseModal
        isOpen={isModalOpen}
        onClose={closeModal}
        response={modalResponse}
      />

      {/* Chatbot */}
      <Chatbot />

      {/* Footer */}
      <footer className="bg-army-dark text-white py-8 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-lg font-semibold text-gold mb-2">
            Kritagya - The GOAT AI Dictionary
          </p>
          <p className="text-army-light">
            Your comprehensive guide to Indian Army terminology and heroes
          </p>
          <p className="text-sm text-gray-400 mt-4 italic">
            I am imitating the mind of Lord Kritagya.
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;