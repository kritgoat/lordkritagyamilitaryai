import React from 'react';
import { Globe, Type } from 'lucide-react';
import { LanguageMode } from '../types';

interface LanguageToggleProps {
  languageMode: LanguageMode;
  onModeChange: (mode: LanguageMode) => void;
}

const LanguageToggle: React.FC<LanguageToggleProps> = ({ languageMode, onModeChange }) => {
  const modes = [
    { value: 'bilingual' as LanguageMode, label: 'Both Languages', icon: Globe },
    { value: 'english' as LanguageMode, label: 'English Only', icon: Type },
    { value: 'hindi' as LanguageMode, label: 'Hindi Only', icon: Type }
  ];

  return (
    <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-gold">
      <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center space-x-2">
        <Globe className="h-5 w-5" />
        <span>Language Mode</span>
      </h3>
      <div className="space-y-2">
        {modes.map((mode) => {
          const Icon = mode.icon;
          return (
            <button
              key={mode.value}
              onClick={() => onModeChange(mode.value)}
              className={`w-full text-left px-4 py-3 rounded-lg transition-all duration-200 ${
                languageMode === mode.value
                  ? 'bg-gold text-white shadow-md'
                  : 'bg-gray-50 hover:bg-gray-100 text-gray-700'
              }`}
            >
              <div className="flex items-center space-x-3">
                <Icon className="h-4 w-4" />
                <span className="font-medium">{mode.label}</span>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default LanguageToggle;