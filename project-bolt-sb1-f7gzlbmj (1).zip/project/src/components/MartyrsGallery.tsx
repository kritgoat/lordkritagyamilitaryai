import React, { useState } from 'react';
import { Heart, Award, MapPin, Calendar, User, Shield } from 'lucide-react';
import { martyrs } from '../data/martyrs';
import { Martyr } from '../types';

const MartyrsGallery: React.FC = () => {
  const [selectedMartyr, setSelectedMartyr] = useState<Martyr | null>(null);

  const openModal = (martyr: Martyr) => {
    setSelectedMartyr(martyr);
  };

  const closeModal = () => {
    setSelectedMartyr(null);
  };

  return (
    <div className="space-y-8">
      {/* Header Section */}
      <div className="text-center bg-gradient-to-r from-army-dark to-army-medium rounded-xl p-8 text-white">
        <div className="flex items-center justify-center space-x-3 mb-4">
          <Heart className="h-8 w-8 text-gold" />
          <Shield className="h-10 w-10 text-gold" />
          <Heart className="h-8 w-8 text-gold" />
        </div>
        <h2 className="text-3xl md:text-4xl font-bold mb-4">
          <span className="text-gold">Martyrs Gallery</span>
        </h2>
        <p className="text-xl text-army-light max-w-3xl mx-auto">
          Honoring the brave souls who made the ultimate sacrifice for our motherland. 
          Their courage, dedication, and supreme sacrifice will forever inspire generations.
        </p>
        <p className="text-sm mt-4 italic text-gold">
          "Shaheedon ki chitaon par lagenge har baras mele, 
          Watan pe mitne walon ka yahi baki nishaan hoga"
        </p>
      </div>

      {/* Martyrs Grid */}
      <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {martyrs.map((martyr) => (
          <div
            key={martyr.id}
            className="bg-white rounded-xl shadow-lg hover:shadow-2xl transition-all duration-300 overflow-hidden border-l-4 border-gold cursor-pointer transform hover:scale-105"
            onClick={() => openModal(martyr)}
          >
            <div className="relative">
              <img
                src={martyr.imageUrl}
                alt={martyr.name}
                className="w-full h-48 object-cover"
                loading="lazy"
              />
              <div className="absolute top-4 right-4 bg-army-dark text-white px-3 py-1 rounded-full text-xs font-semibold">
                {martyr.award.split(' ')[0]}
              </div>
            </div>
            
            <div className="p-6">
              <h3 className="text-xl font-bold text-army-dark mb-2">{martyr.name}</h3>
              <div className="space-y-2 text-sm text-gray-600">
                <div className="flex items-center space-x-2">
                  <User className="h-4 w-4 text-army-medium" />
                  <span>{martyr.rank}, {martyr.unit}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Calendar className="h-4 w-4 text-army-medium" />
                  <span>{martyr.dateOfSacrifice}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <MapPin className="h-4 w-4 text-army-medium" />
                  <span>{martyr.location}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Award className="h-4 w-4 text-gold" />
                  <span className="font-medium text-army-dark">{martyr.award}</span>
                </div>
              </div>
              
              <div className="mt-4 pt-4 border-t border-gray-100">
                <p className="text-xs text-gray-500 italic text-center">
                  Click to read their heroic story
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Modal */}
      {selectedMartyr && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="relative">
              <img
                src={selectedMartyr.imageUrl}
                alt={selectedMartyr.name}
                className="w-full h-64 object-cover rounded-t-xl"
              />
              <button
                onClick={closeModal}
                className="absolute top-4 right-4 bg-black bg-opacity-50 text-white rounded-full p-2 hover:bg-opacity-75 transition-colors"
              >
                <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            
            <div className="p-8">
              <div className="text-center mb-6">
                <h2 className="text-3xl font-bold text-army-dark mb-2">{selectedMartyr.name}</h2>
                <p className="text-lg text-army-medium">{selectedMartyr.rank}, {selectedMartyr.unit}</p>
                <div className="inline-flex items-center space-x-2 bg-gold text-white px-4 py-2 rounded-full mt-3">
                  <Award className="h-5 w-5" />
                  <span className="font-semibold">{selectedMartyr.award}</span>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6 mb-6">
                <div className="space-y-3">
                  <div className="flex items-center space-x-3">
                    <Calendar className="h-5 w-5 text-army-medium" />
                    <div>
                      <p className="text-sm text-gray-600">Date of Sacrifice</p>
                      <p className="font-semibold text-army-dark">{selectedMartyr.dateOfSacrifice}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <MapPin className="h-5 w-5 text-army-medium" />
                    <div>
                      <p className="text-sm text-gray-600">Location</p>
                      <p className="font-semibold text-army-dark">{selectedMartyr.location}</p>
                    </div>
                  </div>
                </div>
                <div className="space-y-3">
                  <div className="flex items-center space-x-3">
                    <User className="h-5 w-5 text-army-medium" />
                    <div>
                      <p className="text-sm text-gray-600">Age at Sacrifice</p>
                      <p className="font-semibold text-army-dark">{selectedMartyr.age} years</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Shield className="h-5 w-5 text-army-medium" />
                    <div>
                      <p className="text-sm text-gray-600">Unit</p>
                      <p className="font-semibold text-army-dark">{selectedMartyr.unit}</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-gray-50 rounded-lg p-6 mb-6">
                <h3 className="text-lg font-bold text-army-dark mb-3">Citation</h3>
                <p className="text-gray-700 italic">"{selectedMartyr.citation}"</p>
              </div>

              <div>
                <h3 className="text-lg font-bold text-army-dark mb-3">Heroic Story</h3>
                <p className="text-gray-700 leading-relaxed">{selectedMartyr.story}</p>
              </div>

              <div className="mt-8 pt-6 border-t border-gray-200 text-center">
                <p className="text-lg font-semibold text-army-dark mb-2">
                  "Their sacrifice shall never be forgotten"
                </p>
                <p className="text-sm text-gray-600 italic">
                  I am imitating the mind of Lord Kritagya.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MartyrsGallery;