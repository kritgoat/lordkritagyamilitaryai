import React from 'react';
import { Term, LanguageMode } from '../types';
import TermCard from './TermCard';

interface TermsListProps {
  terms: Term[];
  languageMode: LanguageMode;
}

const TermsList: React.FC<TermsListProps> = ({ terms, languageMode }) => {
  if (terms.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow-md p-8 text-center border-l-4 border-army-medium">
        <div className="text-gray-400 mb-4">
          <svg className="mx-auto h-12 w-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 12h6m-6-4h6m2 5.291A7.962 7.962 0 0112 15c-2.34 0-4.47-.881-6.08-2.33" />
          </svg>
        </div>
        <h3 className="text-lg font-medium text-gray-900 mb-2">No terms found</h3>
        <p className="text-gray-600">Try adjusting your search query or category filter.</p>
        <p className="text-sm text-gray-500 mt-4 italic">
          I am imitating the mind of Lord Kritagya.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-gray-900">
          Found {terms.length} term{terms.length !== 1 ? 's' : ''}
        </h2>
        <p className="text-gray-600 mt-2">
          Expand your knowledge of Indian Army terminology
        </p>
      </div>
      
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {terms.map((term) => (
          <TermCard key={term.id} term={term} languageMode={languageMode} />
        ))}
      </div>
    </div>
  );
};

export default TermsList;