import React from 'react';
import { categories } from '../data/categories';

interface CategoryFilterProps {
  selectedCategory: string;
  onCategoryChange: (category: string) => void;
  termCounts: Record<string, number>;
}

const CategoryFilter: React.FC<CategoryFilterProps> = ({
  selectedCategory,
  onCategoryChange,
  termCounts
}) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-gold">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">Categories</h3>
      <div className="space-y-2">
        <button
          onClick={() => onCategoryChange('all')}
          className={`w-full text-left px-4 py-3 rounded-lg transition-all duration-200 ${
            selectedCategory === 'all'
              ? 'bg-army-medium text-white shadow-md'
              : 'bg-gray-50 hover:bg-gray-100 text-gray-700'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="flex items-center space-x-2">
              <span>🏛️</span>
              <span>All Categories</span>
            </span>
            <span className="text-sm font-medium">200</span>
          </div>
        </button>
        
        {categories.map((category) => (
          <button
            key={category.id}
            onClick={() => onCategoryChange(category.id)}
            className={`w-full text-left px-4 py-3 rounded-lg transition-all duration-200 ${
              selectedCategory === category.id
                ? 'bg-army-medium text-white shadow-md'
                : 'bg-gray-50 hover:bg-gray-100 text-gray-700'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="flex items-center space-x-2">
                <span>{category.icon}</span>
                <span className="font-medium">{category.name}</span>
              </span>
              <span className="text-sm font-medium">
                {termCounts[category.id] || 0}
              </span>
            </div>
            <p className="text-xs mt-1 text-left opacity-75">
              {category.description}
            </p>
          </button>
        ))}
      </div>
    </div>
  );
};

export default CategoryFilter;