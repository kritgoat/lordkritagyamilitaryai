import React from 'react';
import { X, Crown } from 'lucide-react';

interface ResponseModalProps {
  isOpen: boolean;
  onClose: () => void;
  response: string;
}

const ResponseModal: React.FC<ResponseModalProps> = ({ isOpen, onClose, response }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full max-h-[80vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-gray-200 bg-gradient-to-r from-army-medium to-army-dark text-white rounded-t-xl">
          <div className="flex items-center space-x-3">
            <Crown className="h-6 w-6 text-gold" />
            <h2 className="text-xl font-bold">Lord Kritagya Responds</h2>
          </div>
          <button
            onClick={onClose}
            className="text-white hover:text-gold transition-colors"
          >
            <X className="h-6 w-6" />
          </button>
        </div>
        
        <div className="p-6">
          <div className="prose prose-lg max-w-none">
            {response.split('\n').map((line, index) => {
              if (line.startsWith('**') && line.endsWith('**')) {
                return (
                  <h3 key={index} className="text-xl font-bold text-army-dark mb-2">
                    {line.slice(2, -2)}
                  </h3>
                );
              } else if (line.startsWith('*') && line.endsWith('*')) {
                return (
                  <p key={index} className="text-sm italic text-gold font-medium text-center mt-4">
                    {line.slice(1, -1)}
                  </p>
                );
              } else if (line.trim() === '') {
                return <br key={index} />;
              } else {
                return (
                  <p key={index} className="text-gray-700 leading-relaxed mb-2">
                    {line}
                  </p>
                );
              }
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ResponseModal;