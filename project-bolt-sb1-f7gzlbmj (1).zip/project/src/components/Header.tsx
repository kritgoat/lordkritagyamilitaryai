import React from 'react';
import { Shield, Crown } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="bg-gradient-to-r from-army-dark to-army-medium shadow-lg border-b-4 border-gold">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex items-center justify-center space-x-4">
          <div className="flex items-center space-x-3">
            <Shield className="h-10 w-10 text-gold" />
            <Crown className="h-8 w-8 text-gold" />
          </div>
          <div className="text-center">
            <h1 className="text-3xl md:text-4xl font-bold text-white">
              <span className="text-gold">Kritagya</span> - The GOAT AI
            </h1>
            <p className="text-army-light text-lg mt-1">
              Bilingual Dictionary of 200 Indian Army Terms
            </p>
          </div>
          <div className="flex items-center space-x-3">
            <Crown className="h-8 w-8 text-gold" />
            <Shield className="h-10 w-10 text-gold" />
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;