import React from 'react';
import { Term, LanguageMode } from '../types';
import { categories } from '../data/categories';

interface TermCardProps {
  term: Term;
  languageMode: LanguageMode;
}

const TermCard: React.FC<TermCardProps> = ({ term, languageMode }) => {
  const category = categories.find(cat => cat.id === term.category);

  return (
    <div className="bg-white rounded-lg shadow-md hover:shadow-lg transition-all duration-300 border-l-4 border-army-medium hover:border-gold p-6">
      <div className="flex items-start justify-between mb-4">
        <h3 className="text-xl font-bold text-gray-900 hover:text-army-dark transition-colors">
          {term.term}
        </h3>
        <div className="flex items-center space-x-2 text-sm text-gray-600">
          <span>{category?.icon}</span>
          <span className="bg-gray-100 px-2 py-1 rounded-full text-xs font-medium">
            {category?.name}
          </span>
        </div>
      </div>
      
      <div className="space-y-3">
        {(languageMode === 'bilingual' || languageMode === 'english') && (
          <div>
            <p className="text-sm font-medium text-army-dark mb-1">English:</p>
            <p className="text-gray-700 leading-relaxed">{term.english}</p>
          </div>
        )}
        
        {(languageMode === 'bilingual' || languageMode === 'hindi') && (
          <div>
            <p className="text-sm font-medium text-army-dark mb-1">Hindi:</p>
            <p className="text-gray-700 leading-relaxed font-hindi">{term.hindi}</p>
          </div>
        )}
      </div>
      
      <div className="mt-4 pt-4 border-t border-gray-100">
        <p className="text-xs text-gray-500 italic text-center">
          I am imitating the mind of Lord Kritagya.
        </p>
      </div>
    </div>
  );
};

export default TermCard;