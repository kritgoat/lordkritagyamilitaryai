import React from 'react';
import { Settings, Sun, Moon, Type, Plus, Minus } from 'lucide-react';
import { AppSettings } from '../types';

interface AccessibilityPanelProps {
  settings: AppSettings;
  onSettingsChange: (settings: AppSettings) => void;
}

const AccessibilityPanel: React.FC<AccessibilityPanelProps> = ({ settings, onSettingsChange }) => {
  const adjustFontSize = (increment: number) => {
    const newSize = Math.max(12, Math.min(24, settings.fontSize + increment));
    onSettingsChange({ ...settings, fontSize: newSize });
  };

  const toggleDarkMode = () => {
    onSettingsChange({ ...settings, darkMode: !settings.darkMode });
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-army-medium">
      <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center space-x-2">
        <Settings className="h-5 w-5" />
        <span>Accessibility</span>
      </h3>
      
      <div className="space-y-4">
        {/* Font Size Control */}
        <div>
          <label className="text-sm font-medium text-gray-700 mb-2 block">
            Font Size
          </label>
          <div className="flex items-center space-x-2">
            <button
              onClick={() => adjustFontSize(-2)}
              className="p-2 bg-gray-100 hover:bg-gray-200 rounded-md transition-colors"
              aria-label="Decrease font size"
            >
              <Minus className="h-4 w-4" />
            </button>
            <span className="text-sm font-medium px-3 py-1 bg-gray-50 rounded-md min-w-[3rem] text-center">
              {settings.fontSize}px
            </span>
            <button
              onClick={() => adjustFontSize(2)}
              className="p-2 bg-gray-100 hover:bg-gray-200 rounded-md transition-colors"
              aria-label="Increase font size"
            >
              <Plus className="h-4 w-4" />
            </button>
          </div>
        </div>
        
        {/* Dark Mode Toggle */}
        <div>
          <label className="text-sm font-medium text-gray-700 mb-2 block">
            Theme Mode
          </label>
          <button
            onClick={toggleDarkMode}
            className={`w-full px-4 py-3 rounded-lg transition-all duration-200 flex items-center space-x-3 ${
              settings.darkMode
                ? 'bg-gray-800 text-white'
                : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
            }`}
          >
            {settings.darkMode ? (
              <Moon className="h-4 w-4" />
            ) : (
              <Sun className="h-4 w-4" />
            )}
            <span>{settings.darkMode ? 'Dark Mode' : 'Light Mode'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default AccessibilityPanel;