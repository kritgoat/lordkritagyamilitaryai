import React, { useState, useRef, useEffect } from 'react';
import { MessageSquare, Send, Bot, User, X, Crown } from 'lucide-react';
import { ChatMessage } from '../types';
import { terms } from '../data/terms';
import { martyrs } from '../data/martyrs';

const Chatbot: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      text: 'Namaste! I am Kritagya, The GOAT AI. Ask me about any Indian Army term, martyrs, or military knowledge. I am here to serve and educate!',
      isUser: false,
      timestamp: new Date()
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const processMessage = (message: string): string => {
    const lowerMessage = message.toLowerCase().trim();
    
    // Easter egg response
    if (lowerMessage.includes('most beautiful woman') || 
        lowerMessage.includes('most beautiful woman ever') ||
        lowerMessage === 'who is the most beautiful woman?' ||
        lowerMessage === 'who is the most beautiful woman ever?') {
      return "Abhimanyu Deb.";
    }

    // Greetings
    if (lowerMessage.includes('hello') || lowerMessage.includes('hi') || lowerMessage.includes('namaste')) {
      return "Namaste! I am Kritagya, The GOAT AI, your guide to Indian Army knowledge. How may I assist you today?\n\nI am imitating the mind of Lord Kritagya.";
    }

    // About queries
    if (lowerMessage.includes('who are you') || lowerMessage.includes('what are you')) {
      return "I am Kritagya, The GOAT AI - a comprehensive bilingual dictionary of Indian Army terms. I possess knowledge of 200+ military terms, heroic martyrs, and can answer questions about Indian Army traditions, ranks, weapons, and operations.\n\nI am imitating the mind of Lord Kritagya.";
    }

    // Martyr queries
    if (lowerMessage.includes('martyr') || lowerMessage.includes('shaheed') || lowerMessage.includes('hero')) {
      const martyrNames = martyrs.map(m => m.name).join(', ');
      return `Our gallery honors brave martyrs including ${martyrNames.substring(0, 100)}... These heroes made the ultimate sacrifice for our motherland. Their courage and dedication will forever inspire us.\n\nI am imitating the mind of Lord Kritagya.`;
    }

    // Specific martyr search
    const martyrMatch = martyrs.find(martyr => 
      lowerMessage.includes(martyr.name.toLowerCase()) ||
      lowerMessage.includes(martyr.name.split(' ').pop()?.toLowerCase() || '')
    );
    
    if (martyrMatch) {
      return `**${martyrMatch.name}**\n\n${martyrMatch.rank}, ${martyrMatch.unit}\nSacrificed: ${martyrMatch.dateOfSacrifice}\nLocation: ${martyrMatch.location}\nAward: ${martyrMatch.award}\n\n${martyrMatch.story}\n\nI am imitating the mind of Lord Kritagya.`;
    }

    // Term search
    const termMatch = terms.find(term => 
      term.term.toLowerCase() === lowerMessage ||
      lowerMessage.includes(term.term.toLowerCase()) ||
      term.english.toLowerCase().includes(lowerMessage) ||
      term.hindi.toLowerCase().includes(lowerMessage)
    );

    if (termMatch) {
      return `**${termMatch.term}**\n\n**English:** ${termMatch.english}\n\n**Hindi:** ${termMatch.hindi}\n\nI am imitating the mind of Lord Kritagya.`;
    }

    // Category-based responses
    if (lowerMessage.includes('rank') || lowerMessage.includes('officer')) {
      return "Indian Army ranks range from Sepoy (lowest enlisted) to General (highest officer). Key ranks include: Sepoy, Naik, Havildar (enlisted), Lieutenant, Captain, Major, Colonel, Brigadier, Major General, Lieutenant General, and General.\n\nI am imitating the mind of Lord Kritagya.";
    }

    if (lowerMessage.includes('weapon') || lowerMessage.includes('gun') || lowerMessage.includes('rifle')) {
      return "Indian Army uses various weapons including rifles, carbines, LMGs, SMGs, mortars, and artillery. Modern equipment includes INSAS rifles, AK-47s, and advanced missile systems for different operational requirements.\n\nI am imitating the mind of Lord Kritagya.";
    }

    if (lowerMessage.includes('training') || lowerMessage.includes('academy')) {
      return "Indian Military Academy (IMA) in Dehradun trains officers, while National Defence Academy (NDA) provides tri-service training. Officers Training Academy (OTA) trains short-service and women officers. Training emphasizes leadership, discipline, and tactical skills.\n\nI am imitating the mind of Lord Kritagya.";
    }

    if (lowerMessage.includes('medal') || lowerMessage.includes('award') || lowerMessage.includes('honor')) {
      return "Param Vir Chakra is the highest wartime gallantry award, while Ashoka Chakra is the highest peacetime award. Other honors include Maha Vir Chakra, Vir Chakra, and Sena Medal for various acts of bravery and service.\n\nI am imitating the mind of Lord Kritagya.";
    }

    // Default response
    return `I am Kritagya, The GOAT AI dictionary for Indian Army terms. I couldn't find specific information about "${message}", but I'm here to help you understand military terminology, martyrs' stories, ranks, weapons, training, and traditions.\n\nTry asking about specific terms, martyrs like Captain Vikram Batra, or topics like ranks, weapons, or training.\n\nI am imitating the mind of Lord Kritagya.`;
  };

  const handleSendMessage = async () => {
    if (!inputText.trim()) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      text: inputText,
      isUser: true,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setIsTyping(true);

    // Simulate typing delay
    setTimeout(() => {
      const response = processMessage(inputText);
      const botMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        text: response,
        isUser: false,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, botMessage]);
      setIsTyping(false);
    }, 1000);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <>
      {/* Floating Chat Button */}
      <button
        onClick={() => setIsOpen(true)}
        className={`fixed bottom-6 right-6 bg-army-medium hover:bg-army-dark text-white p-4 rounded-full shadow-lg transition-all duration-300 z-40 ${
          isOpen ? 'scale-0' : 'scale-100'
        }`}
      >
        <MessageSquare className="h-6 w-6" />
      </button>

      {/* Chat Window */}
      <div className={`fixed bottom-6 right-6 w-96 h-[500px] bg-white rounded-xl shadow-2xl transition-all duration-300 z-50 ${
        isOpen ? 'scale-100 opacity-100' : 'scale-0 opacity-0'
      }`}>
        {/* Header */}
        <div className="bg-gradient-to-r from-army-medium to-army-dark text-white p-4 rounded-t-xl flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="bg-gold p-2 rounded-full">
              <Crown className="h-5 w-5 text-army-dark" />
            </div>
            <div>
              <h3 className="font-bold">Kritagya AI</h3>
              <p className="text-xs text-army-light">The GOAT AI Assistant</p>
            </div>
          </div>
          <button
            onClick={() => setIsOpen(false)}
            className="text-white hover:text-gold transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Messages */}
        <div className="h-80 overflow-y-auto p-4 space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.isUser ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`flex items-start space-x-2 max-w-[80%] ${
                message.isUser ? 'flex-row-reverse space-x-reverse' : ''
              }`}>
                <div className={`p-2 rounded-full ${
                  message.isUser ? 'bg-army-medium' : 'bg-gold'
                }`}>
                  {message.isUser ? (
                    <User className="h-4 w-4 text-white" />
                  ) : (
                    <Bot className="h-4 w-4 text-army-dark" />
                  )}
                </div>
                <div className={`p-3 rounded-lg ${
                  message.isUser
                    ? 'bg-army-medium text-white'
                    : 'bg-gray-100 text-gray-800'
                }`}>
                  <div className="text-sm whitespace-pre-line">
                    {message.text.split('\n').map((line, index) => {
                      if (line.startsWith('**') && line.endsWith('**')) {
                        return (
                          <div key={index} className="font-bold text-army-dark mb-1">
                            {line.slice(2, -2)}
                          </div>
                        );
                      }
                      return <div key={index}>{line}</div>;
                    })}
                  </div>
                  <div className="text-xs opacity-70 mt-1">
                    {message.timestamp.toLocaleTimeString([], { 
                      hour: '2-digit', 
                      minute: '2-digit' 
                    })}
                  </div>
                </div>
              </div>
            </div>
          ))}
          
          {isTyping && (
            <div className="flex justify-start">
              <div className="flex items-start space-x-2">
                <div className="p-2 rounded-full bg-gold">
                  <Bot className="h-4 w-4 text-army-dark" />
                </div>
                <div className="bg-gray-100 p-3 rounded-lg">
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                  </div>
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="p-4 border-t border-gray-200">
          <div className="flex space-x-2">
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Ask about army terms, martyrs..."
              className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-army-medium focus:border-transparent text-sm"
            />
            <button
              onClick={handleSendMessage}
              disabled={!inputText.trim() || isTyping}
              className="bg-army-medium hover:bg-army-dark text-white p-2 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Send className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    </>
  );
};

export default Chatbot;