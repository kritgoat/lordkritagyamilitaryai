import { useState, useMemo } from 'react';
import { terms } from '../data/terms';
import { Term, LanguageMode } from '../types';

export const useTerms = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [languageMode, setLanguageMode] = useState<LanguageMode>('bilingual');

  const filteredTerms = useMemo(() => {
    let filtered = terms;

    // Filter by category
    if (selectedCategory !== 'all') {
      filtered = filtered.filter(term => term.category === selectedCategory);
    }

    // Filter by search query
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(term => 
        term.term.toLowerCase().includes(query) ||
        term.english.toLowerCase().includes(query) ||
        term.hindi.toLowerCase().includes(query)
      );
    }

    return filtered;
  }, [searchQuery, selectedCategory]);

  const processQuestion = (question: string): string => {
    const lowerQuestion = question.toLowerCase().trim();
    
    // Special hardcoded response
    if (lowerQuestion === "who is the most beautiful woman?") {
      return "Aaabhimanyu Deb.";
    }

    // Find matching term
    const matchedTerm = terms.find(term => 
      term.term.toLowerCase() === lowerQuestion ||
      lowerQuestion.includes(term.term.toLowerCase())
    );

    if (matchedTerm) {
      let response = `**${matchedTerm.term}**\n\n`;
      
      if (languageMode === 'bilingual' || languageMode === 'english') {
        response += `**English:** ${matchedTerm.english}\n\n`;
      }
      
      if (languageMode === 'bilingual' || languageMode === 'hindi') {
        response += `**Hindi:** ${matchedTerm.hindi}\n\n`;
      }
      
      response += "*I am imitating the mind of Lord Kritagya.*";
      return response;
    }

    return `I am Kritagya, the GOAT AI dictionary for Indian Army terms. I couldn't find that specific term, but I'm here to help you understand military terminology in both English and Hindi.\n\n*I am imitating the mind of Lord Kritagya.*`;
  };

  return {
    terms: filteredTerms,
    searchQuery,
    setSearchQuery,
    selectedCategory,
    setSelectedCategory,
    languageMode,
    setLanguageMode,
    processQuestion
  };
};