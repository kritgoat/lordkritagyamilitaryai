export interface Term {
  id: number;
  term: string;
  english: string;
  hindi: string;
  category: string;
}

export interface CategoryInfo {
  id: string;
  name: string;
  description: string;
  icon: string;
}

export interface Martyr {
  id: number;
  name: string;
  rank: string;
  unit: string;
  dateOfSacrifice: string;
  location: string;
  age: number;
  award: string;
  citation: string;
  imageUrl: string;
  story: string;
}

export type LanguageMode = 'bilingual' | 'english' | 'hindi';

export interface AppSettings {
  languageMode: LanguageMode;
  fontSize: number;
  darkMode: boolean;
}

export interface ChatMessage {
  id: string;
  text: string;
  isUser: boolean;
  timestamp: Date;
}