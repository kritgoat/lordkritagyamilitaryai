import { CategoryInfo } from '../types';

export const categories: CategoryInfo[] = [
  { id: 'structure', name: 'Structure & Units', description: 'Military organization and formations', icon: '🏛️' },
  { id: 'ranks', name: 'Ranks & Personnel', description: 'Military hierarchy and positions', icon: '⭐' },
  { id: 'weapons', name: 'Weapons & Equipment', description: 'Arms and military hardware', icon: '⚔️' },
  { id: 'combat', name: 'Combat & Doctrine', description: 'Battle tactics and principles', icon: '🎯' },
  { id: 'operations', name: 'Strategy & Operations', description: 'Military planning and execution', icon: '📋' },
  { id: 'training', name: 'Training & Academies', description: 'Education and skill development', icon: '🎓' },
  { id: 'discipline', name: 'Law & Discipline', description: 'Military justice and order', icon: '⚖️' },
  { id: 'logistics', name: 'Logistics & Support', description: 'Supply chains and maintenance', icon: '📦' },
  { id: 'communication', name: 'Communication & Signals', description: 'Information systems and networks', icon: '📡' },
  { id: 'honors', name: 'Honors & Awards', description: 'Recognition and decorations', icon: '🏅' },
  { id: 'culture', name: 'Culture & Traditions', description: 'Military heritage and customs', icon: '🏛️' }
];