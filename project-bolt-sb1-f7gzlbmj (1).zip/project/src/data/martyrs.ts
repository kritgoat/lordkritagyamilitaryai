import { Martyr } from '../types';

export const martyrs: Martyr[] = [
  {
    id: 1,
    name: "Captain Vikram Batra",
    rank: "Captain",
    unit: "13 Jammu and Kashmir Rifles",
    dateOfSacrifice: "July 7, 1999",
    location: "Point 5140, Dras Sector, Kargil",
    age: 24,
    award: "Param Vir Chakra (Posthumous)",
    citation: "For most conspicuous bravery during the Kargil operations",
    imageUrl: "https://images.pexels.com/photos/8926553/pexels-photo-8926553.jpeg",
    story: "Captain Vikram Batra led from the front during the Kargil War. His famous war cry 'Yeh Dil Maange More!' became legendary. He successfully captured Point 5140 and was killed while trying to rescue a fellow officer during the capture of Point 4875. His courage and leadership inspired his men to victory even after his sacrifice."
  },
  {
    id: 2,
    name: "Major Somnath Sharma",
    rank: "Major",
    unit: "4 Kumaon Regiment",
    dateOfSacrifice: "November 3, 1947",
    location: "Badgam, Kashmir",
    age: 31,
    award: "Param Vir Chakra (Posthumous)",
    citation: "First recipient of Param Vir Chakra for exceptional bravery",
    imageUrl: "https://images.pexels.com/photos/8926554/pexels-photo-8926554.jpeg",
    story: "Major Somnath Sharma was the first recipient of the Param Vir Chakra. During the 1947 Kashmir operations, he led his company against overwhelming odds. Despite being heavily outnumbered, he fought valiantly until his last breath, inflicting heavy casualties on the enemy and buying crucial time for reinforcements."
  },
  {
    id: 3,
    name: "Lieutenant Manoj Kumar Pandey",
    rank: "Lieutenant",
    unit: "1/11 Gorkha Rifles",
    dateOfSacrifice: "July 3, 1999",
    location: "Batalik Sector, Kargil",
    age: 24,
    award: "Param Vir Chakra (Posthumous)",
    citation: "For displaying indomitable courage during Kargil operations",
    imageUrl: "https://images.pexels.com/photos/8926555/pexels-photo-8926555.jpeg",
    story: "Lieutenant Manoj Kumar Pandey led the assault on Khalubar Hills during the Kargil War. Despite being severely injured, he continued to lead his men and captured the enemy position. His last words were 'Na Chhodnu' (Don't leave them), inspiring his troops to complete the mission."
  },
  {
    id: 4,
    name: "Captain Anuj Nayyar",
    rank: "Captain",
    unit: "17 Jat Regiment",
    dateOfSacrifice: "July 7, 1999",
    location: "Point 4875, Tiger Hill, Kargil",
    age: 23,
    award: "Maha Vir Chakra (Posthumous)",
    citation: "For conspicuous gallantry and leadership under fire",
    imageUrl: "https://images.pexels.com/photos/8926556/pexels-photo-8926556.jpeg",
    story: "Captain Anuj Nayyar displayed exceptional courage during the capture of Tiger Hill. He led multiple assaults against heavily fortified enemy positions. Even after being fatally wounded, he continued to motivate his troops and ensured the success of the operation."
  },
  {
    id: 5,
    name: "Rifleman Sanjay Kumar",
    rank: "Rifleman",
    unit: "13 Jammu and Kashmir Rifles",
    dateOfSacrifice: "Still Serving",
    location: "Point 4875, Mushkoh Valley, Kargil",
    age: 22,
    award: "Param Vir Chakra",
    citation: "For individual acts of bravery and leadership",
    imageUrl: "https://images.pexels.com/photos/8926557/pexels-photo-8926557.jpeg",
    story: "Rifleman Sanjay Kumar showed extraordinary courage during the Kargil War. Despite being injured, he destroyed enemy bunkers single-handedly and cleared the way for his company. He survived his heroic actions and continues to serve as an inspiration to all soldiers."
  },
  {
    id: 6,
    name: "Grenadier Yogendra Singh Yadav",
    rank: "Grenadier",
    unit: "18 Grenadiers",
    dateOfSacrifice: "Still Serving",
    location: "Tiger Hill, Kargil",
    age: 19,
    award: "Param Vir Chakra",
    citation: "Youngest recipient of Param Vir Chakra for exceptional bravery",
    imageUrl: "https://images.pexels.com/photos/8926558/pexels-photo-8926558.jpeg",
    story: "At just 19, Grenadier Yogendra Singh Yadav became the youngest recipient of the Param Vir Chakra. During the assault on Tiger Hill, he climbed a vertical cliff face under heavy fire and destroyed enemy bunkers. Despite multiple bullet wounds, he continued fighting until the position was captured."
  },
  {
    id: 7,
    name: "Major Padmapani Acharya",
    rank: "Major",
    unit: "2 Rajputana Rifles",
    dateOfSacrifice: "May 28, 1999",
    location: "Tololing, Kargil",
    age: 32,
    award: "Maha Vir Chakra (Posthumous)",
    citation: "For leading from the front with exceptional courage",
    imageUrl: "https://images.pexels.com/photos/8926559/pexels-photo-8926559.jpeg",
    story: "Major Padmapani Acharya led the successful assault on Tololing during the Kargil War. He motivated his troops through personal example and tactical brilliance. His sacrifice paved the way for the capture of this strategic height, which was crucial for the overall success of Operation Vijay."
  },
  {
    id: 8,
    name: "Captain Haneef Uddin",
    rank: "Captain",
    unit: "11 Rajputana Rifles",
    dateOfSacrifice: "June 21, 1999",
    location: "Turtuk Sector, Kargil",
    age: 26,
    award: "Vir Chakra (Posthumous)",
    citation: "For displaying courage and determination in operations",
    imageUrl: "https://images.pexels.com/photos/8926560/pexels-photo-8926560.jpeg",
    story: "Captain Haneef Uddin showed remarkable leadership during operations in the Turtuk Sector. He led his men with distinction and made the ultimate sacrifice while ensuring the safety of his troops. His dedication to duty and his men exemplified the finest traditions of the Indian Army."
  }
];